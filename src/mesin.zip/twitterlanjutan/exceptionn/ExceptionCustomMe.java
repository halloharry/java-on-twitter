package twitterlanjutan.exceptionn;

// kelas exception Khusus yang kita buat bray
public class ExceptionCustomMe extends Exception {

    public ExceptionCustomMe(String message) {
        super(message);
    }
}
